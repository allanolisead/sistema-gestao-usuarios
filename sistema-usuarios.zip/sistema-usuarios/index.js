const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const fs = require('fs');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());

const SECRET_KEY = 'minha_chave_secreta'; // Chave secreta para o token JWT
let blacklistedTokens = []; // Lista de tokens revogados

// Função para carregar usuários do arquivo JSON
function carregarUsuarios() {
  const dados = fs.readFileSync('usuarios.json', 'utf8');
  return JSON.parse(dados);
}

// Função para salvar usuários no arquivo JSON
function salvarUsuarios(usuarios) {
  fs.writeFileSync('usuarios.json', JSON.stringify(usuarios, null, 2));
}

// Função para carregar os dados (itens) do arquivo JSON
function carregarDados() {
  const dados = fs.readFileSync('dados.json', 'utf8');
  return JSON.parse(dados);
}

// Função para salvar os dados (itens) no arquivo JSON
function salvarDados(dados) {
  fs.writeFileSync('dados.json', JSON.stringify(dados, null, 2));
}

// Middleware para verificar se o token está revogado
function verificarTokenRevogado(token) {
  return blacklistedTokens.includes(token);
}

// Rota para registrar novo usuário
app.post('/register', (req, res) => {
  const { username, password } = req.body;
  const usuarios = carregarUsuarios();
  const usuarioExistente = usuarios.find(user => user.username === username);
  if (usuarioExistente) {
    return res.status(400).json({ message: 'Usuário já existe' });
  }
  const senhaHash = bcrypt.hashSync(password, 10);
  const novoUsuario = { username, password: senhaHash };
  usuarios.push(novoUsuario);
  salvarUsuarios(usuarios);
  res.status(201).json({ message: 'Usuário registrado com sucesso!' });
});

// Rota para login e geração de token JWT
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  const usuarios = carregarUsuarios();
  const usuario = usuarios.find(user => user.username === username);
  if (!usuario) {
    return res.status(404).json({ message: 'Usuário não encontrado' });
  }
  const senhaValida = bcrypt.compareSync(password, usuario.password);
  if (!senhaValida) {
    return res.status(401).json({ message: 'Senha inválida' });
  }
  const token = jwt.sign({ username }, SECRET_KEY, { expiresIn: '1h' });
  res.json({ token });
});

// Rota de logout para revogar o token atual
app.post('/logout', (req, res) => {
  const token = req.headers['authorization'];
  if (!token) {
    return res.status(401).json({ message: 'Token não fornecido' });
  }
  blacklistedTokens.push(token.split(' ')[1]);
  res.json({ message: 'Logout realizado com sucesso' });
});

// Rota protegida para acessar dados
app.get('/protected', (req, res) => {
  const token = req.headers['authorization'];
  if (!token) {
    return res.status(401).json({ message: 'Token não fornecido' });
  }
  if (verificarTokenRevogado(token.split(' ')[1])) {
    return res.status(401).json({ message: 'Token revogado. Faça login novamente.' });
  }
  jwt.verify(token.split(' ')[1], SECRET_KEY, (err, decoded) => {
    if (err) {
      return res.status(401).json({ message: 'Token inválido ou expirado' });
    }
    res.json({ message: 'Acesso permitido', user: decoded.username });
  });
});

// CRUD: Criar item (POST /items)
app.post('/items', (req, res) => {
  const token = req.headers['authorization'];
  if (!token) {
    return res.status(401).json({ message: 'Token não fornecido' });
  }
  if (verificarTokenRevogado(token.split(' ')[1])) {
    return res.status(401).json({ message: 'Token revogado. Faça login novamente.' });
  }
  jwt.verify(token.split(' ')[1], SECRET_KEY, (err, decoded) => {
    if (err) {
      return res.status(401).json({ message: 'Token inválido ou expirado' });
    }
    const { title, content } = req.body;
    const dados = carregarDados();
    const novoItem = {
      id: dados.length + 1,
      title,
      content,
      user: decoded.username
    };
    dados.push(novoItem);
    salvarDados(dados);
    res.status(201).json({ message: 'Item criado com sucesso', item: novoItem });
  });
});

// CRUD: Listar todos os itens do usuário (GET /items)
app.get('/items', (req, res) => {
  const token = req.headers['authorization'];
  if (!token) {
    return res.status(401).json({ message: 'Token não fornecido' });
  }
  if (verificarTokenRevogado(token.split(' ')[1])) {
    return res.status(401).json({ message: 'Token revogado. Faça login novamente.' });
  }
  jwt.verify(token.split(' ')[1], SECRET_KEY, (err, decoded) => {
    if (err) {
      return res.status(401).json({ message: 'Token inválido ou expirado' });
    }
    const dados = carregarDados();
    const itensUsuario = dados.filter(item => item.user === decoded.username);
    res.json(itensUsuario);
  });
});

// CRUD: Atualizar item por ID (PUT /items/:id)
app.put('/items/:id', (req, res) => {
  const token = req.headers['authorization'];
  if (!token) {
    return res.status(401).json({ message: 'Token não fornecido' });
  }
  if (verificarTokenRevogado(token.split(' ')[1])) {
    return res.status(401).json({ message: 'Token revogado. Faça login novamente.' });
  }
  jwt.verify(token.split(' ')[1], SECRET_KEY, (err) => {
    if (err) {
      return res.status(401).json({ message: 'Token inválido ou expirado' });
    }
    const { id } = req.params;
    const { title, content } = req.body;
    const dados = carregarDados();
    const item = dados.find(item => item.id === parseInt(id));
    if (!item) {
      return res.status(404).json({ message: 'Item não encontrado' });
    }
    item.title = title || item.title;
    item.content = content || item.content;
    salvarDados(dados);
    res.json({ message: 'Item atualizado com sucesso', item });
  });
});

// CRUD: Deletar item por ID (DELETE /items/:id)
app.delete('/items/:id', (req, res) => {
  const token = req.headers['authorization'];
  if (!token) {
    return res.status(401).json({ message: 'Token não fornecido' });
  }
  if (verificarTokenRevogado(token.split(' ')[1])) {
    return res.status(401).json({ message: 'Token revogado. Faça login novamente.' });
  }
  jwt.verify(token.split(' ')[1], SECRET_KEY, (err) => {
    if (err) {
      return res.status(401).json({ message: 'Token inválido ou expirado' });
    }
    const { id } = req.params;
    let dados = carregarDados();
    const novoDados = dados.filter(item => item.id !== parseInt(id));
    if (dados.length === novoDados.length) {
      return res.status(404).json({ message: 'Item não encontrado' });
    }
    salvarDados(novoDados);
    res.json({ message: 'Item deletado com sucesso' });
  });
});

// Inicia o servidor na porta 3000
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});
